# 本地目录验收 clarifications
固定目录安装、更新、重装使用的真实业务成果。